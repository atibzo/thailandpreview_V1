
import React from 'react'
import ThailandFranchiseLanding from './ThailandFranchiseLanding'

export default function App(){
  return <ThailandFranchiseLanding />
}
